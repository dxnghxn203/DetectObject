from enum import Enum

class Value(Enum):
    path_model = 'models/'

    #tkinter
    geometry = "1000x600"
    title = "Server models"

    logo = r'assets/images/Logo.png'
    



