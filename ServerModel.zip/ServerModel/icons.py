
plus = "➕"
minus = "➖"
wastebasket ="🗑️"